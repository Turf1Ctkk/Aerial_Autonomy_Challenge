<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1415647601857'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.installFolder' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer'/>
    <property name='org.eclipse.equinox.p2.cache' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
    <property name='eclipse.touchpoint.launcherName' value='CP21xxCustomizationUtility'/>
  </properties>
  <units size='43'>
    <unit id='a.jre.javase' version='1.6.0' singleton='false'>
      <provides size='159'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='1.6.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activity' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.wsaddressing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.ORBPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.TypeCodePackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextExtPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Messaging' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor.ORBInitInfoPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.CurrentPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAManagerPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.ServantLocatorPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.SendingContext' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.stub.java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.silabs.customizer' version='1.2.0.201411101325'>
      <update id='com.silabs.customizer' range='[0.0.0,1.2.0.201411101325)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Customizer'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Laboratories'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer' version='1.2.0.201411101325'/>
        <provided namespace='osgi.bundle' name='com.silabs.customizer' version='1.2.0.201411101325'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='com.silabs.jna' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.silabs.nebula' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='3.7.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.silabs.customizer' version='1.2.0.201411101325'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.silabs.customizer; singleton:=true&#xA;Bundle-Version: 1.2.0.201411101325
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.silabs.customizer-feature.feature.group' version='1.0.0.201411101325' singleton='false'>
      <update id='com.silabs.customizer-feature.feature.group' range='[0.0.0,1.0.0.201411101325)' severity='0'/>
      <properties size='5'>
        <property name='org.eclipse.equinox.p2.name' value='Device Customizer Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Labs'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature.feature.group' version='1.0.0.201411101325'/>
      </provides>
      <requires size='42'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='3.7.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.7.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.2.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.4.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.3.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='0.0.0'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.0.0,4.0.0)'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer' range='[1.2.0.201411101325,1.2.0.201411101325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.jna' range='[3.4.0.201411101325,3.4.0.201411101325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.nebula' range='[1.0.0.20120606,1.0.0.20120606]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.6.1.v20120912-135020,3.6.1.v20120912-135020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.4.200.v20120523-2004,3.4.200.v20120523-2004]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.5.200.v20120521-2346,3.5.200.v20120521-2346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.8.0.v20120521-2346,3.8.0.v20120521-2346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.3.100.v20120522-1841,1.3.100.v20120522-1841]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.6.100.v20120522-1841,3.6.100.v20120522-1841]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.5.1.v20121031-182809,3.5.1.v20121031-182809]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.5.200.v20120522-1841,3.5.200.v20120522-1841]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.8.0.v20120912-135020,3.8.0.v20120912-135020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.8.2.v20130124-134944,3.8.2.v20130124-134944]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.8.1.v3836b,3.8.1.v3836b]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx' range='[3.8.1.v3836b,3.8.1.v3836b]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86' range='[3.8.1.v3836b,3.8.1.v3836b]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' range='[3.8.1.v3836b,3.8.1.v3836b]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature.feature.jar' range='[1.0.0.201411101325,1.0.0.201411101325]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root' range='[1.0.0.201411101325,1.0.0.201411101325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root.gtk.linux.x86' range='[1.0.0.201411101325,1.0.0.201411101325]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root.cocoa.macosx.x86' range='[1.0.0.201411101325,1.0.0.201411101325]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root.win32.win32.x86' range='[1.0.0.201411101325,1.0.0.201411101325]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='com.silabs.customizer-feature.feature.jar' version='1.0.0.201411101325'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Device Customizer Feature'/>
        <property name='org.eclipse.equinox.p2.description' value='[Enter Feature Description here.]'/>
        <property name='org.eclipse.equinox.p2.description.url' value='http://www.example.com/description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Labs'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature.feature.jar' version='1.0.0.201411101325'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='com.silabs.customizer-feature' version='1.0.0.201411101325'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='com.silabs.customizer-feature' version='1.0.0.201411101325'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://www.example.com/license' url='http://www.example.com/license'>
          [Enter License Description here.]
        </license>
      </licenses>
      <copyright uri='http://www.example.com/copyright' url='http://www.example.com/copyright'>
        [Enter Copyright Description here.]
      </copyright>
    </unit>
    <unit id='com.silabs.customizer-feature_root' version='1.0.0.201411101325'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root' version='1.0.0.201411101325'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='com.silabs.customizer-feature_root' version='1.0.0.201411101325'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.silabs.customizer-feature_root.win32.win32.x86' version='1.0.0.201411101325'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature_root.win32.win32.x86' version='1.0.0.201411101325'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='com.silabs.customizer-feature_root.win32.win32.x86' version='1.0.0.201411101325'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.silabs.ide.jre-feature.feature.group' version='1.6.0.32' singleton='false'>
      <update id='com.silabs.ide.jre-feature.feature.group' range='[0.0.0,1.6.0.32)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='Simplicity Studio Bundled Java Runtime'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Labs'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='com.silabs.studio.description' value='This feature provides the Java Runtime Environment for Simplicity Studio'/>
        <property name='com.silabs.studio.releaseNotes.version.1.6.0.32' value='[[Core Support]]&#xA;No changes from the official 1.6.0.32 distribution'/>
        <property name='df_LT.description' value='This feature provides the Java Runtime Environment for Simplicity Studio&#xA;&#xA;Known Issues&#xA;========================&#xA;None&#xA;&#xA;Version 1.6.0.32&#xA;========================&#xA;No changes from the official 1.6.0.32 distribution'/>
        <property name='df_LT.copyright' value='Copyright (c) 2014 Silicon Laboratories, Inc.'/>
        <property name='df_LT.license' value='Please refer to http://java.com/license for the JRE license&#xA;&#xA;&#xA;END-USER LICENSE AGREEMENT&#xA;IMPORTANT:  READ CAREFULLY&#xA;BEFORE AGREEING TO TERMS&#xA;&#xA;THIS PRODUCT CONTAINS CERTAIN COMPUTER PROGRAMS AND OTHER THIRD&#xA;PARTY PROPRIETARY MATERIAL (&quot;LICENSED PRODUCT&quot;), THE USE OF WHICH&#xA;IS SUBJECT TO THIS END-USER LICENSE AGREEMENT. INDICATING YOUR&#xA;AGREEMENT CONSTITUTES YOUR AND (IF APPLICABLE) YOUR COMPANY&apos;S&#xA;ASSENT TO AND ACCEPTANCE OF THIS END-USER LICENSE AGREEMENT (THE&#xA;&quot;LICENSE&quot; OR &quot;AGREEMENT&quot;).  IF YOU DO NOT AGREE WITH ALL OF THE&#xA;TERMS, YOU MUST NOT USE THIS PRODUCT.  WRITTEN APPROVAL IS NOT&#xA;A PREREQUISITE TO THE VALIDITY OR ENFORCEABILITY OF THIS AGREEMENT,&#xA;AND NO SOLICITATION OF SUCH WRITTEN APPROVAL BY OR ON BEHALF&#xA;OF SILICON LABORATORIES, INC. (&quot;SILICON LABS&quot;) SHALL BE CONSTRUED&#xA;AS AN INFERENCE TO THE CONTRARY.  IF THESE TERMS ARE CONSIDERED&#xA;AN OFFER BY SILICON LABS, ACCEPTANCE IS EXPRESSLY LIMITED TO THESE&#xA;TERMS.&#xA;&#xA;LICENSE AND WARRANTY:  The Licensed Product and the embedded&#xA;Software which is made the subject of this License is either&#xA;the property of SILICON LABS or a third party from whom SILICON LABS&#xA;has the authorization to distribute to you subject to the terms of&#xA;this Agreement.  This Licensed Product is protected by state,&#xA;federal, and international copyright law. Although SILICON LABS continues&#xA;to own the Licensed Product and the right to distribute the embedded&#xA;third party Software, you will have certain rights to use the&#xA;Licensed Product and the embedded Software after your acceptance&#xA;of this License. Except as may be modified by a license addendum&#xA;which accompanies this License, your rights and obligations with&#xA;respect to the use of this Product and the embedded software&#xA;are as follows:&#xA;&#xA;1.  AS APPROPRIATE WITH RESPECT TO THE LICENSED PRODUCT, YOU MAY:&#xA;Use, copy, distribute and make derivative works of the Software for&#xA;any purpose, including commercial applications, subject to the following&#xA;restrictions: (i) The origin of this software must not be misrepresented;&#xA;(ii) you must not claim that you wrote the original software; (iii)&#xA;altered source versions must be plainly marked as such, and must not be&#xA;misrepresented as being the original software; and (iv) any notices&#xA;contained in the Software may not be removed or altered, including&#xA;notices in source code versions.&#xA;&#xA;2.  YOU MAY NOT: (A) Sublicense, assign, rent or lease any portion of&#xA;the Licensed Product or the embedded Software; or (B) Remove any&#xA;product identification, copyright or other notices that appear on&#xA;the Licensed Product or embedded Software.&#xA;&#xA;3.  Limited Use:  Use of any of the Software is strictly limited to&#xA;use in systems containing one or more SILICON LABS products when the&#xA;Software is enabled to be functional.  Any unauthorized use is expressly&#xA;prohibited and will constitute a breach of this Agreement.&#xA;&#xA;4.  Warranty:  SILICON LABS does not warrant that the Licensed Product&#xA;or embedded Software will meet your requirements or that operation of&#xA;the Licensed Product will be uninterrupted or that the embedded Software&#xA;will be error-free.  You agree that the Licensed Product is provided&#xA;&quot;AS IS&quot; and that SILICON LABS makes no warranty as to the Licensed&#xA;Product or embedded Software.  SILICON LABS DISCLAIMS ALL WARRANTIES,&#xA;EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES&#xA;OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT,&#xA;RELATED TO THE SOFTWARE, ITS USE OR ANY INABILITY TO USE IT, THE RESULTS&#xA;OF ITS USE AND THIS AGREEMENT.&#xA;&#xA;YOU MAY HAVE OTHER RIGHTS, WHICH VARY FROM STATE TO STATE.&#xA;&#xA;5.  Disclaimer of Damages:  IN NO EVENT WILL SILICON LABS BE LIABLE TO&#xA;YOU FOR ANY SPECIAL, CONSEQUENTIAL, INDIRECT, OR SIMILAR DAMAGES, INCLUDING&#xA;ANY LOST PROFITS OR LOST DATA ARISING OUT OF THE USE OR INABILITY TO USE&#xA;THE LICENSED PRODUCT EVEN IF SILICON LABS HAS BEEN ADVISED OF THE POSSIBILITY&#xA;OF SUCH DAMAGES.&#xA;&#xA;SOME STATES DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY FOR&#xA;INCIDENTAL OR CONSEQUENTIAL DAMAGES. SO THE ABOVE LIMITATION OR EXCLUSION&#xA;MAY NOT APPLY TO YOU.&#xA;&#xA;IN NO CASE SHALL SILICON LABS&apos; LIABILITY EXCEED THE PURCHASE PRICE FOR&#xA;THE LICENSED PRODUCT.  The disclaimers and limitations set forth above&#xA;will apply regardless of whether you accept the Licensed Software.&#xA;&#xA;6.  Term and Termination:  The term of this Agreement and the License&#xA;granted herein shall begin upon use of the Licensed Product and continue&#xA;in perpetuity unless you breach any of the obligations set out under&#xA;this Agreement.  Upon your breach of this Agreement by you, the license&#xA;granted hereunder shall terminate immediately and you shall cease all&#xA;use of the Licensed Products and return same as well as any copies of&#xA;the Licensed Product and/or embedded Software to SILICON LABS immediately.&#xA;Termination of this License upon your breach is only one remedy available&#xA;to SILICON LABS. In addition to termination of this Agreement upon your&#xA;breach, SILICON LABS shall be entitled to seek any and all other available&#xA;remedies, at law or at equity, arising from your breach.&#xA;&#xA;7.  Export: You shall comply with all applicable federal, provincial,&#xA;state and local laws, regulations and ordinances including but not&#xA;limited to applicable U.S. Export Administration Laws and Regulations.&#xA;You shall not export or re-export, or allow the export or re-export of&#xA;the Licensed Product, any component of the Licensed Product, or any copy&#xA;of the embedded Software in violation of any such restrictions, laws or&#xA;regulations, or to Cuba, Libya, North Korea, Iran, Iraq, or Rwanda or to&#xA;any Group D:1 or E:2 country (or any national of such country) specified&#xA;in the then current Supplement No. 1 to Part 740, or, in violation of the&#xA;embargo provisions in Part 746, of the U.S. Export Administration&#xA;Regulations (or any successor regulations or supplement), except in&#xA;compliance with and with all licenses and approvals required under&#xA;applicable export laws and regulations, including without limitation,&#xA;those of the U.S. Department of Commerce.&#xA;&#xA;8.  General: This Agreement will be governed by the laws of the State&#xA;of Texas and any applicable federal laws or regulations. The waiver by&#xA;either Party of any default or breach of this Agreement shall not&#xA;constitute a waiver of any other or subsequent default or breach.&#xA;This Agreement constitutes the complete and exclusive statement of&#xA;the mutual understanding between you and SILICON LABS with respect&#xA;to this subject matter herein. This Agreement may only be modified&#xA;by a written addendum, which has been signed by both you and SILICON&#xA;LABS. Should you have any questions concerning this Agreement, or if&#xA;you desire to contact SILICON LABS for any reason, please write:&#xA;&#xA;Silicon Laboratories, Inc.&#xA;400 West Cesar Chavez&#xA;Austin, Texas 78701, U.S.A.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature.feature.group' version='1.6.0.32'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature.feature.jar' range='[1.6.0.32,1.6.0.32]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature_root.gtk.linux.x86' range='[1.6.0.32,1.6.0.32]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature_root.win32.win32.x86' range='[1.6.0.32,1.6.0.32]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='com.silabs.ide.jre-feature.feature.jar' version='1.6.0.32'>
      <properties size='6'>
        <property name='org.eclipse.equinox.p2.name' value='Simplicity Studio Bundled Java Runtime'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Labs'/>
        <property name='df_LT.description' value='This feature provides the Java Runtime Environment for Simplicity Studio&#xA;&#xA;Known Issues&#xA;========================&#xA;None&#xA;&#xA;Version 1.6.0.32&#xA;========================&#xA;No changes from the official 1.6.0.32 distribution'/>
        <property name='df_LT.copyright' value='Copyright (c) 2014 Silicon Laboratories, Inc.'/>
        <property name='df_LT.license' value='Please refer to http://java.com/license for the JRE license&#xA;&#xA;&#xA;END-USER LICENSE AGREEMENT&#xA;IMPORTANT:  READ CAREFULLY&#xA;BEFORE AGREEING TO TERMS&#xA;&#xA;THIS PRODUCT CONTAINS CERTAIN COMPUTER PROGRAMS AND OTHER THIRD&#xA;PARTY PROPRIETARY MATERIAL (&quot;LICENSED PRODUCT&quot;), THE USE OF WHICH&#xA;IS SUBJECT TO THIS END-USER LICENSE AGREEMENT. INDICATING YOUR&#xA;AGREEMENT CONSTITUTES YOUR AND (IF APPLICABLE) YOUR COMPANY&apos;S&#xA;ASSENT TO AND ACCEPTANCE OF THIS END-USER LICENSE AGREEMENT (THE&#xA;&quot;LICENSE&quot; OR &quot;AGREEMENT&quot;).  IF YOU DO NOT AGREE WITH ALL OF THE&#xA;TERMS, YOU MUST NOT USE THIS PRODUCT.  WRITTEN APPROVAL IS NOT&#xA;A PREREQUISITE TO THE VALIDITY OR ENFORCEABILITY OF THIS AGREEMENT,&#xA;AND NO SOLICITATION OF SUCH WRITTEN APPROVAL BY OR ON BEHALF&#xA;OF SILICON LABORATORIES, INC. (&quot;SILICON LABS&quot;) SHALL BE CONSTRUED&#xA;AS AN INFERENCE TO THE CONTRARY.  IF THESE TERMS ARE CONSIDERED&#xA;AN OFFER BY SILICON LABS, ACCEPTANCE IS EXPRESSLY LIMITED TO THESE&#xA;TERMS.&#xA;&#xA;LICENSE AND WARRANTY:  The Licensed Product and the embedded&#xA;Software which is made the subject of this License is either&#xA;the property of SILICON LABS or a third party from whom SILICON LABS&#xA;has the authorization to distribute to you subject to the terms of&#xA;this Agreement.  This Licensed Product is protected by state,&#xA;federal, and international copyright law. Although SILICON LABS continues&#xA;to own the Licensed Product and the right to distribute the embedded&#xA;third party Software, you will have certain rights to use the&#xA;Licensed Product and the embedded Software after your acceptance&#xA;of this License. Except as may be modified by a license addendum&#xA;which accompanies this License, your rights and obligations with&#xA;respect to the use of this Product and the embedded software&#xA;are as follows:&#xA;&#xA;1.  AS APPROPRIATE WITH RESPECT TO THE LICENSED PRODUCT, YOU MAY:&#xA;Use, copy, distribute and make derivative works of the Software for&#xA;any purpose, including commercial applications, subject to the following&#xA;restrictions: (i) The origin of this software must not be misrepresented;&#xA;(ii) you must not claim that you wrote the original software; (iii)&#xA;altered source versions must be plainly marked as such, and must not be&#xA;misrepresented as being the original software; and (iv) any notices&#xA;contained in the Software may not be removed or altered, including&#xA;notices in source code versions.&#xA;&#xA;2.  YOU MAY NOT: (A) Sublicense, assign, rent or lease any portion of&#xA;the Licensed Product or the embedded Software; or (B) Remove any&#xA;product identification, copyright or other notices that appear on&#xA;the Licensed Product or embedded Software.&#xA;&#xA;3.  Limited Use:  Use of any of the Software is strictly limited to&#xA;use in systems containing one or more SILICON LABS products when the&#xA;Software is enabled to be functional.  Any unauthorized use is expressly&#xA;prohibited and will constitute a breach of this Agreement.&#xA;&#xA;4.  Warranty:  SILICON LABS does not warrant that the Licensed Product&#xA;or embedded Software will meet your requirements or that operation of&#xA;the Licensed Product will be uninterrupted or that the embedded Software&#xA;will be error-free.  You agree that the Licensed Product is provided&#xA;&quot;AS IS&quot; and that SILICON LABS makes no warranty as to the Licensed&#xA;Product or embedded Software.  SILICON LABS DISCLAIMS ALL WARRANTIES,&#xA;EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES&#xA;OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT,&#xA;RELATED TO THE SOFTWARE, ITS USE OR ANY INABILITY TO USE IT, THE RESULTS&#xA;OF ITS USE AND THIS AGREEMENT.&#xA;&#xA;YOU MAY HAVE OTHER RIGHTS, WHICH VARY FROM STATE TO STATE.&#xA;&#xA;5.  Disclaimer of Damages:  IN NO EVENT WILL SILICON LABS BE LIABLE TO&#xA;YOU FOR ANY SPECIAL, CONSEQUENTIAL, INDIRECT, OR SIMILAR DAMAGES, INCLUDING&#xA;ANY LOST PROFITS OR LOST DATA ARISING OUT OF THE USE OR INABILITY TO USE&#xA;THE LICENSED PRODUCT EVEN IF SILICON LABS HAS BEEN ADVISED OF THE POSSIBILITY&#xA;OF SUCH DAMAGES.&#xA;&#xA;SOME STATES DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY FOR&#xA;INCIDENTAL OR CONSEQUENTIAL DAMAGES. SO THE ABOVE LIMITATION OR EXCLUSION&#xA;MAY NOT APPLY TO YOU.&#xA;&#xA;IN NO CASE SHALL SILICON LABS&apos; LIABILITY EXCEED THE PURCHASE PRICE FOR&#xA;THE LICENSED PRODUCT.  The disclaimers and limitations set forth above&#xA;will apply regardless of whether you accept the Licensed Software.&#xA;&#xA;6.  Term and Termination:  The term of this Agreement and the License&#xA;granted herein shall begin upon use of the Licensed Product and continue&#xA;in perpetuity unless you breach any of the obligations set out under&#xA;this Agreement.  Upon your breach of this Agreement by you, the license&#xA;granted hereunder shall terminate immediately and you shall cease all&#xA;use of the Licensed Products and return same as well as any copies of&#xA;the Licensed Product and/or embedded Software to SILICON LABS immediately.&#xA;Termination of this License upon your breach is only one remedy available&#xA;to SILICON LABS. In addition to termination of this Agreement upon your&#xA;breach, SILICON LABS shall be entitled to seek any and all other available&#xA;remedies, at law or at equity, arising from your breach.&#xA;&#xA;7.  Export: You shall comply with all applicable federal, provincial,&#xA;state and local laws, regulations and ordinances including but not&#xA;limited to applicable U.S. Export Administration Laws and Regulations.&#xA;You shall not export or re-export, or allow the export or re-export of&#xA;the Licensed Product, any component of the Licensed Product, or any copy&#xA;of the embedded Software in violation of any such restrictions, laws or&#xA;regulations, or to Cuba, Libya, North Korea, Iran, Iraq, or Rwanda or to&#xA;any Group D:1 or E:2 country (or any national of such country) specified&#xA;in the then current Supplement No. 1 to Part 740, or, in violation of the&#xA;embargo provisions in Part 746, of the U.S. Export Administration&#xA;Regulations (or any successor regulations or supplement), except in&#xA;compliance with and with all licenses and approvals required under&#xA;applicable export laws and regulations, including without limitation,&#xA;those of the U.S. Department of Commerce.&#xA;&#xA;8.  General: This Agreement will be governed by the laws of the State&#xA;of Texas and any applicable federal laws or regulations. The waiver by&#xA;either Party of any default or breach of this Agreement shall not&#xA;constitute a waiver of any other or subsequent default or breach.&#xA;This Agreement constitutes the complete and exclusive statement of&#xA;the mutual understanding between you and SILICON LABS with respect&#xA;to this subject matter herein. This Agreement may only be modified&#xA;by a written addendum, which has been signed by both you and SILICON&#xA;LABS. Should you have any questions concerning this Agreement, or if&#xA;you desire to contact SILICON LABS for any reason, please write:&#xA;&#xA;Silicon Laboratories, Inc.&#xA;400 West Cesar Chavez&#xA;Austin, Texas 78701, U.S.A.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature.feature.jar' version='1.6.0.32'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='com.silabs.ide.jre-feature' version='1.6.0.32'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='com.silabs.ide.jre-feature' version='1.6.0.32'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='com.silabs.ide.jre-feature_root.win32.win32.x86' version='1.6.0.32'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature_root.win32.win32.x86' version='1.6.0.32'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='com.silabs.ide.jre-feature_root.win32.win32.x86' version='1.6.0.32'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.silabs.jna' version='3.4.0.201411101325' singleton='false'>
      <update id='com.silabs.jna' range='[0.0.0,3.4.0.201411101325)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='JNA library'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Laboratories'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.jna' version='3.4.0.201411101325'/>
        <provided namespace='osgi.bundle' name='com.silabs.jna' version='3.4.0.201411101325'/>
        <provided namespace='java.package' name='com.sun.jna' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jna.ptr' version='0.0.0'/>
        <provided namespace='java.package' name='com.sun.jna.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.silabs.jna' version='3.4.0.201411101325'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.silabs.jna&#xA;Bundle-Version: 3.4.0.201411101325
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.silabs.nebula' version='1.0.0.20120606' singleton='false'>
      <update id='com.silabs.nebula' range='[0.0.0,1.0.0.20120606)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='Nebula Widgets'/>
        <property name='org.eclipse.equinox.p2.provider' value='Silicon Laboratories'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.silabs.nebula' version='1.0.0.20120606'/>
        <provided namespace='osgi.bundle' name='com.silabs.nebula' version='1.0.0.20120606'/>
        <provided namespace='java.package' name='com.silabs.nebula.widgets.pgroup' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='3.7.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.silabs.nebula' version='1.0.0.20120606'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.silabs.nebula&#xA;Bundle-Version: 1.0.0.20120606
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='config.a.jre.javase' version='1.6.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' version='1.6.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='install'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='customizer' version='1.0.0'>
      <update id='customizer' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='CP21xx Customization Utility'/>
        <property name='lineUp' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='customizer' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.200.v20120522-1813,1.1.200.v20120522-1813]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.common' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer_root.gtk.linux.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='customizer.root.feature.feature.group' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.configuration' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='customizer_root.cocoa.macosx.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.ide.jre-feature.feature.group' range='[1.6.0.32,1.6.0.32]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer_root.cocoa.macosx.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer_root.win32.win32.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='customizer_root.win32.win32.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.3.0.v20120522-1813,1.3.0.v20120522-1813]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='customizer_root.gtk.linux.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.3.0.v20120522-1813,1.3.0.v20120522-1813]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.silabs.customizer-feature.feature.group' range='[1.0.0.201411101325,1.0.0.201411101325]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.osgi' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.200.v20120522-1813,1.1.200.v20120522-1813]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.core.runtime' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
    </unit>
    <unit id='customizer.root.feature.feature.group' version='1.0.0' singleton='false'>
      <update id='customizer.root.feature.feature.group' range='[0.0.0,1.0.0)' severity='0'/>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.name' value='CP21xx Customization Utility Root Files'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='customizer.root.feature.feature.group' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='customizer.root.feature_root' range='[1.0.0,1.0.0]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='customizer.root.feature_root' version='1.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='customizer.root.feature_root' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='customizer.root.feature_root' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='customizer_root.win32.win32.x86' version='1.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='customizer_root.win32.win32.x86' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='customizer_root.win32.win32.x86' version='1.0.0'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.6.1.v20120912-135020' singleton='false'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.6.1.v20120912-135020)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.6.1.v20120912-135020'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.6.1.v20120912-135020'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.6.1.v20120912-135020'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.6.1.v20120912-135020
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.4.200.v20120523-2004'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.4.200.v20120523-2004)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.4.200.v20120523-2004'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.4.200.v20120523-2004'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.4.200.v20120523-2004'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.4.200.v20120523-2004
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.5.200.v20120521-2346'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.5.200.v20120521-2346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.5.200.v20120521-2346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.5.200.v20120521-2346'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.5.200.v20120521-2346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.5.200.v20120521-2346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.8.0.v20120521-2346'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.8.0.v20120521-2346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.8.0.v20120521-2346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.8.0.v20120521-2346'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.auth' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.8.0.v20120521-2346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.8.0.v20120521-2346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.3.100.v20120522-1841'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.3.100.v20120522-1841)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.3.100.v20120522-1841'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.3.100.v20120522-1841'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.3.100.v20120522-1841'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.3.100.v20120522-1841
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.6.100.v20120522-1841'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.6.100.v20120522-1841)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.6.100.v20120522-1841'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.6.100.v20120522-1841'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.6.100.v20120522-1841'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.6.100.v20120522-1841
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.3.0.v20120522-1813'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.3.0.v20120522-1813)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.3.0.v20120522-1813'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.3.0.v20120522-1813'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.3.0.v20120522-1813'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.3.0.v20120522-1813
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807'>
      <update id='org.eclipse.equinox.launcher.win32.win32.x86' range='[0.0.0,1.1.200.v20120913-144807)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher Win32 X86 Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.win32.win32.x86'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.1.200.v20120913-144807'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.0.0,1.4.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 1.1.200.v20120913-144807&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.0.0,1.4.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.5.1.v20121031-182809'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.5.1.v20121031-182809)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.5.1.v20121031-182809'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.5.1.v20121031-182809'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.5.1.v20121031-182809'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.5.1.v20121031-182809
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.5.200.v20120522-1841'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.5.200.v20120522-1841)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.5.200.v20120522-1841'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.5.200.v20120522-1841'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.5.200.v20120522-1841'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.5.200.v20120522-1841
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface' version='3.8.0.v20120912-135020' singleton='false'>
      <update id='org.eclipse.jface' range='[0.0.0,3.8.0.v20120912-135020)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' version='3.8.0.v20120912-135020'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface' version='3.8.0.v20120912-135020'/>
        <provided namespace='java.package' name='org.eclipse.jface' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.provisional.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.deferred' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard.images' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface' version='3.8.0.v20120912-135020'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface&#xA;Bundle-Version: 3.8.0.v20120912-135020
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.8.2.v20130124-134944'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.8.2.v20130124-134944)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
      </properties>
      <provides size='72'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.8.2.v20130124-134944'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.8.2.v20130124-134944'/>
        <provided namespace='java.package' name='org.eclipse.osgi.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.6.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver.extras' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.7.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.namespace' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.resource' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.framework' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.1'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.stats' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.hooks' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleentry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleresource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.module' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.profile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.permadmin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.8.2.v20130124-134944'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.8.2.v20130124-134944
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.3.100.v20120522-1822' singleton='false'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.3.100.v20120522-1822)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.3.100.v20120522-1822'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.3.100.v20120522-1822'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.4.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.component.annotations' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.io' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.1,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.io' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='javax.microedition.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.4.0,1.5.0)'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.1,1.1.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.3.100.v20120522-1822'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.3.100.v20120522-1822
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt' version='3.8.1.v3836b'>
      <update id='org.eclipse.swt' range='[0.0.0,3.8.1.v3836b)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Standard Widget Toolkit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' version='3.8.1.v3836b'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt' version='3.8.1.v3836b'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.theme' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.eclipse.swt.accessibility2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mozilla.xpcom' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt' version='3.8.1.v3836b'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt; singleton:=true&#xA;Bundle-Version: 3.8.1.v3836b
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.win32.win32.x86' version='3.8.1.v3836b'>
      <update id='org.eclipse.swt.win32.win32.x86' range='[0.0.0,3.8.1.v3836b)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Standard Widget Toolkit for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' version='3.8.1.v3836b'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.win32.win32.x86' version='3.8.1.v3836b'/>
        <provided namespace='java.package' name='org.eclipse.swt.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gdip' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.opengl.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.8.1.v3836b'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.0.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.win32.win32.x86' version='3.8.1.v3836b'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 3.8.1.v3836b&#xA;Fragment-Host: org.eclipse.swt; bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcustomizer.config.win32.win32.x86' version='1.0.0' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.config.win32.win32.x86' version='1.0.0'/>
        <provided namespace='toolingcustomizer' name='customizer.config' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.application,propValue:);setProgramProperty(propName:eclipse.product,propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.application,propValue:com.silabs.customizer.application);setProgramProperty(propName:eclipse.product,propValue:com.silabs.customizer.product);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcustomizer.configuration' version='1.0.0'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.configuration' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.ini.win32.win32.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.ini.gtk.linux.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.config.win32.win32.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.ini.cocoa.macosx.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.config.cocoa.macosx.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.config.gtk.linux.x86' range='[1.0.0,1.0.0]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingcustomizer.ini.win32.win32.x86' version='1.0.0' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer.ini.win32.win32.x86' version='1.0.0'/>
        <provided namespace='toolingcustomizer' name='customizer.ini' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-vm);removeProgramArg(programArg:common/jre/bin);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-vm);addProgramArg(programArg:common/jre/bin);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingcustomizer_root.win32.win32.x86' version='1.0.0' singleton='false'>
      <properties size='1'>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingcustomizer_root.win32.win32.x86' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setLauncherName()
          </instruction>
          <instruction key='configure'>
            setLauncherName(name:CP21xxCustomizationUtility)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.core.runtime' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.8.0.v20120521-2346,3.8.0.v20120521-2346]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.core.runtime' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.8.0.v20120521-2346,3.8.0.v20120521-2346]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.common' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.100.v20120522-1841,3.6.100.v20120522-1841]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.common' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.6.100.v20120522-1841,3.6.100.v20120522-1841]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.3.0.v20120522-1813' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.3.0.v20120522-1813,1.3.0.v20120522-1813]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.3.0.v20120522-1813'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.3.0.v20120522-1813,1.3.0.v20120522-1813]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.200.v20120913-144807'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.200.v20120913-144807,1.1.200.v20120913-144807]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.osgi' version='1.0.0' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.8.2.v20130124-134944,3.8.2.v20130124-134944]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.osgi' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.8.2.v20130124-134944,3.8.2.v20130124-134944]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started:false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:-1);markStarted(started:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='43'>
    <iuProperties id='com.silabs.customizer-feature_root' version='1.0.0.201411101325'>
      <properties size='1'>
        <property name='unzipped|@artifact|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\Release_Notes.txt|'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.silabs.customizer-feature_root.win32.win32.x86' version='1.0.0.201411101325'>
      <properties size='1'>
        <property name='unzipped|@artifact|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\Release_Notes.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\SLABHIDtoUART.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\CP210xManufacturing.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\SLABHIDDevice.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\SLAB_USB_SPI.dll|'/>
      </properties>
    </iuProperties>
    <iuProperties id='com.silabs.ide.jre-feature_root.win32.win32.x86' version='1.6.0.32'>
      <properties size='1'>
        <property name='unzipped|@artifact|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Hermosillo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Thimphu|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Riyadh|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Harbin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Syowa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\cmm.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Havana|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Cocos|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm\sRGB.pf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\San_Juan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Manaus|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Canary|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Rainy_River|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Faroe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Antigua|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Campo_Grande|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Phnom_Penh|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpiexp.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Palmer|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\CST6|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Bissau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Jamaica|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Hong_Kong|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\chrome|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\chrome\content|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\chrome\content\overlay.xul|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\JdbcOdbc.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Martinique|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fontconfig.properties.src|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Vilnius|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\MST7|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Resolute|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Bahrain|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Novokuznetsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Sofia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Paramaribo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Dili|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Pago_Pago|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Currie|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Chagos|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Brazzaville|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_LinkNoDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpeg.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\ssv.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Abidjan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Tijuana|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Gibraltar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Omsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\policytool.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\GMT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\plugin2|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\plugin2\npjp2.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Puerto_Rico|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\DumontDUrville|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ie|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ie\jqs_plugin.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpioji.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Hovd|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Indianapolis|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaBrightDemiItalic.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Boa_Vista|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Dubai|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Windhoek|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Dar_es_Salaam|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Ouagadougou|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Pontianak|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Buenos_Aires|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\tzmappings|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jsound.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Monterrey|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kuching|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Vaduz|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\PST8|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\java_crw_demo.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Kentucky|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Kentucky\Louisville|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Ojinaga|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dtplugin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dtplugin\deployJava1.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Mahe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\pack200.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Jujuy|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Sao_Tome|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\YST9YDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Belize|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Ushuaia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Beirut|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\jqsmessages.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Guam|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Davis|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\j2pcsc.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\audio|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\audio\soundbank.gm|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Dawson_Creek|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Helsinki|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Harare|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Tahiti|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Vostok|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Dushanbe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Inuvik|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\sunjce_provider.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Amsterdam|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+11|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+12|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Kaliningrad|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+10|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Aruba|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\McMurdo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Krasnoyarsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management\snmp.acl.template|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Andorra|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Managua|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\cursors.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\awt.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\El_Aaiun|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Sakhalin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Gaza|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Santa_Isabel|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\client|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\client\jvm.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\management.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Maldives|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm\CIEXYZ.pf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Salta|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\npoji610.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\North_Dakota|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\North_Dakota\Center|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\EST5EDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Muscat|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Ashgabat|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\javaws.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\kinit.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dt_socket.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Mauritius|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Baghdad|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\psfontj2d.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Baku|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\content-types.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dt_shmem.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Vladivostok|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Paris|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\El_Salvador|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Miquelon|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Montserrat|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_CopyNoDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Almaty|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\AST4|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_MoveDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Knox|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Santiago|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Yekaterinburg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\install.rdf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Darwin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Los_Angeles|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Chisinau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\splash.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Noronha|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Tarawa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Ho_Chi_Minh|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Nassau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Lusaka|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\deploy.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Matamoros|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\jvm.hprof.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Minsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\rmid.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kolkata|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Nome|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Pangnirtung|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\PST8PDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpishare.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Yellowknife|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_sv.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Belgrade|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jqsnotify.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Rankin_Inlet|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Lisbon|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management-agent.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Sydney|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Enderbury|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Antananarivo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\verify.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Port_of_Spain|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\MST7MDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Madrid|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\javacpl.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Barbados|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Freetown|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Perth|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\unpack200.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kabul|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Riga|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\CST6CDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Monrovia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Ulaanbaatar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Wake|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Yerevan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\hprof.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Pitcairn|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\sunmscapi.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Makassar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Nouakchott|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\invalid32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Djibouti|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\sunpkcs11.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Montevideo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Bishkek|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Santarem|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm\PYCC.pf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Irkutsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Vienna|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fontconfig.bfc|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Tirane|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Rio_Branco|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\servicetag|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\servicetag\registration.xml|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Montreal|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Kwajalein|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\servicetag\jdk_header.png|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Choibalsan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Maputo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Madeira|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaTypewriterRegular.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Sao_Paulo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Chatham|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Tongatapu|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Merida|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\PST8PDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\HST|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Moscow|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\UTC|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\ffjcext.zip|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jaas_nt.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\AST4ADT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Brussels|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Adak|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Aden|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Bamako|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\hpi.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Tell_City|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Tashkent|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_ko.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Winamac|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Juba|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Lubumbashi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Goose_Bay|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\St_Lucia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-10|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\unicows.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Anchorage|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Halifax|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\instrument.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Gambier|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Denver|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Lagos|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Norfolk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-13|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-14|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Apia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-11|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jbroker.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-12|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Cordoba|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Zaporozhye|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\axbridge.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Damascus|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Casablanca|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Dawson|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Edmonton|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Funafuti|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Maceio|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\rmiregistry.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Easter|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Zurich|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kashgar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Copenhagen|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kathmandu|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Mogadishu|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Mbabane|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaBrightDemiBold.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Cancun|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\net.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management\management.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_it.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Blantyre|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\St_Vincent|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Majuro|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Curacao|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Stanley|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Aqtobe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Mawson|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\dnsns.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dcpr.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Wallis|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Brisbane|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Azores|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Accra|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Yakutat|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Gaborone|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Rothera|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_zh_CN.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\chrome.manifest|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\rt.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Efate|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Eucla|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Urumqi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Grand_Turk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\nio.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Jakarta|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fontconfig.98.bfc|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Stockholm|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Pyongyang|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Volgograd|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+1|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Qyzylorda|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Winnipeg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+5|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+4|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+3|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\java.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+2|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Dublin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\splashscreen.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\zip.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Sitka|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Noumea|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Maseru|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Cayenne|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\client\classes.jsa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Rarotonga|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Saipan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Berlin|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\README.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Guadalcanal|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Auckland|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\plugin.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\javaws.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Caracas|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\MST7MDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kuala_Lumpur|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Guadeloupe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Dakar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Godthab|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Eirunepe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\localedata.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Broken_Hill|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_pt_BR.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\javaws.policy|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm\GRAY.pf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Hobart|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Araguaina|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\YST9|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Malta|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\jsse.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Chihuahua|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\MST|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Samara|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Cuiaba|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\St_Thomas|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Manila|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\plugin2\msvcr71.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Riyadh88|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Riyadh89|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Addis_Ababa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Riyadh87|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\meta-index|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Niamey|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\CST6CDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Malabo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Galapagos|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Chongqing|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Menominee|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Brunei|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Kentucky\Monticello|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\COPYRIGHT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Hebron|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_fr.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Magadan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\im|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\im\indicim.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Guatemala|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Seoul|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jdwp.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\flavormap.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Glace_Bay|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Uzhgorod|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jawt.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Johnston|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaSansDemiBold.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\regutils.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Ndjamena|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Casey|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\LICENSE.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Vevay|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\keytool.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Lindeman|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\ssvagent.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Bucharest|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Thule|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jp2ssv.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\im\thaiim.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\ktab.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Samarkand|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Lome|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\eula.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Vincennes|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\meta-index|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Christmas|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\ext\sunmscapi.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Cayman|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Grenada|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Fakaofo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Kigali|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Tunis|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Tortola|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\npt.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Marquesas|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Rio_Gallegos|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\Welcome.html|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jp2iexp.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Bujumbura|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\jqs.conf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Luanda|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Athens|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Chicago|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\lzma.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Panama|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\ioser12.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\npjpi160_32.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Toronto|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Fortaleza|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\fontmanager.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\La_Rioja|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Tegucigalpa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\i386|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\i386\jvm.cfg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jp2native.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\dtplugin\npdeployJava1.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Mayotte|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Ceuta|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\St_Kitts|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\java-rmi.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Cambridge_Bay|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Aqtau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaTypewriterBold.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Luxembourg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kuwait|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\South_Georgia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\mlib_image.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Comoro|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Shanghai|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Tbilisi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Scoresbysund|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Belem|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_zh_HK.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Libreville|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Yakutsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Oral|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\La_Paz|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Anguilla|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Kerguelen|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Istanbul|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Swift_Current|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Danmarkshavn|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Reykjavik|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Lima|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\msvcrt.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Tehran|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Atikokan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\EST|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\client\Xusage.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Tripoli|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Catamarca|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Johannesburg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Kampala|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Phoenix|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Juneau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management\jmxremote.access|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\logging.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\local_policy.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Palau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Dhaka|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Bahia_Banderas|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Kamchatka|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\jqs\ff\chrome\content\overlay.js|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\java.policy|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\CET|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Bahia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\net.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Vientiane|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\tnameserv.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Whitehorse|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaSansRegular.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\EET|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Jerusalem|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\wsdetect.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Novosibirsk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Asmara|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Fiji|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaBrightItalic.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Nairobi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Kosrae|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Moncton|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\rmi.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Marengo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Warsaw|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Indian\Reunion|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Porto-Novo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_ja.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Detroit|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Melbourne|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_MoveNoDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Nauru|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\klist.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpinscp.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Recife|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Thunder_Bay|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\javaw.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Rome|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Oslo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Budapest|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\unpack.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Niue|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\THIRDPARTYLICENSEREADME.txt|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jqs.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\trusted.libraries|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Honolulu|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\psfont.properties.ja|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\charsets.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\ZoneInfoMappings|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Karachi|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\San_Luis|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Rangoon|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\St_Johns|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Lord_Howe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Conakry|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\calendars.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Prague|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Blanc-Sablon|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Cape_Verde|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Guyana|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Monaco|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\LICENSE|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Jayapura|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Asuncion|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\UCT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Qatar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\classlist|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jpicom.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Mexico_City|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_de.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Douala|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Pohnpei|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Kiritimati|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fontconfig.98.properties.src|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Tallinn|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Amman|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Kiev|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\EST5EDT|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Guayaquil|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\blacklist|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\fonts\LucidaBrightRegular.ttf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Mendoza|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\jce.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\servertool.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Banjul|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_CopyDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Vancouver|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_es.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jp2launcher.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\MET|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-9|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-8|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\images\cursors\win32_LinkDrop32x32.gif|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Port-au-Prince|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Taipei|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Bogota|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\EST5|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\US_export_policy.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Cairo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Australia\Adelaide|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Nicosia|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Colombo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Macau|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\msvcr71.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jsoundds.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Algiers|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Tokyo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Mazatlan|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\java.security|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\security\cacerts|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Kinshasa|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\SystemV\HST10|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Metlakatla|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Nipigon|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Port_Moresby|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\management\jmxremote.password.template|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Porto_Velho|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\cmm\LINEAR_RGB.pf|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Indiana\Petersburg|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\London|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jli.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Antarctica\Macquarie|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Dominica|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Midway|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\resources.jar|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\WET|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\sound.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-4|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\jkernel.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-5|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\Bermuda|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Bangkok|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-6|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-7|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Iqaluit|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-1|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-2|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT-3|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+9|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\deploy\messages_zh_TW.properties|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Costa_Rica|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+8|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Anadyr|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+7|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Etc\GMT+6|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Santo_Domingo|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\java.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Bangui|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Regina|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\j2pkcs11.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\w2k_lsa_auth.dll|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Africa\Khartoum|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\New_York|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Asia\Singapore|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Argentina\Tucuman|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Pacific\Chuuk|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Europe\Simferopol|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\bin\orbd.exe|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\Atlantic\St_Helena|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\North_Dakota\New_Salem|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\North_Dakota\Beulah|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\common\jre\lib\zi\America\Boise|'/>
      </properties>
    </iuProperties>
    <iuProperties id='customizer' version='1.0.0'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='customizer.root.feature_root' version='1.0.0'>
      <properties size='1'>
        <property name='unzipped|@artifact|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\.eclipseproduct|'/>
      </properties>
    </iuProperties>
    <iuProperties id='customizer_root.win32.win32.x86' version='1.0.0'>
      <properties size='1'>
        <property name='unzipped|@artifact|e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer\CP21xxCustomizationUtility.exe|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>

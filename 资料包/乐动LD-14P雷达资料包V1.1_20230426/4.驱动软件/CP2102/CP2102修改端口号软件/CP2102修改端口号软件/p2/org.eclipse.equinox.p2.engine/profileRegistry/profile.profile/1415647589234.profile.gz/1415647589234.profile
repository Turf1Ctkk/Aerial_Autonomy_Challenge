<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='profile' timestamp='1415647589234'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.installFolder' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer'/>
    <property name='org.eclipse.equinox.p2.cache' value='e:\j\workspace\CP21xx_RCP_App\customizer\tmp\customizer'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
  </properties>
</profile>
